from setuptools import setup


setup(name='mys-bar',
      version='0.1.0',
      description='Short description.',
      long_description=open('README.rst', 'r').read(),
      author='Erik Moqvist',
      author_email='erik.moqvist@gmail.com',
      install_requires=[])
