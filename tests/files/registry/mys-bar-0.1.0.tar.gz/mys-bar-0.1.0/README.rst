Bar
===

A tiny package that is used in the tutorial.
